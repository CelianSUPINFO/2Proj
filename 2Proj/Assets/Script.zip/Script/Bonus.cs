using UnityEngine;

public static class Bonus
{
    public static float woodBonus = 0f;

    // Tu peux ajouter d'autres bonus ici plus tard (ex: stoneBonus, speedBonus...)
}