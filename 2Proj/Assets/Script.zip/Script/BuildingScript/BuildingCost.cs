using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class BuildingCost
{
    public List<ResourceAmount> resourceCosts;
}
