public enum BuildingFunction
{
    Housing,
    FoodProduction,
    WaterProduction,
    Storage,
    ResourceExtraction,
    Refinement,
    Research,
    Social,
    Distribution,
    Transport,
    AnimalFarm,
    None
}
