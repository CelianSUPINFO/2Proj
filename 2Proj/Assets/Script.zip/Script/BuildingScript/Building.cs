using UnityEngine;

public class Building : MonoBehaviour
{
    public BuildingData data;

    
}
