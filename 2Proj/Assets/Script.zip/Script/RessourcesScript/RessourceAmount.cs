using UnityEngine;

[System.Serializable]
public class ResourceAmount
{
    public ResourceType type;
    public int amount;
}
