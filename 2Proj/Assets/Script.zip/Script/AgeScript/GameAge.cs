public enum GameAge
{
    StoneAge,
    AncientAge,
    MedievalAge,
    IndustrialAge
}
